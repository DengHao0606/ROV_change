#include "RS485_process.h"
#include "comm.h"

#include "usart.h"
#include "tim.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*
 * 函数名: void Transmit_485_IT
 * 描述  : RS485中断发送
 * 输入  : UART_HandleTypeDef *huart, uint8_t *buf, uint16_t len, GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin
 * 输出  : /
 * 备注  : /
 */
void Transmit_485_IT(UART_HandleTypeDef *huart, uint8_t *buf, uint16_t len, GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
    HAL_GPIO_WritePin(GPIOx, GPIO_Pin, GPIO_PIN_SET);
    HAL_Delay(1);
    HAL_UART_Transmit_IT(huart, buf, len);
    // HAL_Delay(1);
    HAL_GPIO_WritePin(GPIOx, GPIO_Pin, GPIO_PIN_RESET);
}

/*
 * 函数名: init_485
 * 描述  : RS485串口初始化
 * 输入  : UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size, GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin
 * 输出  : /
 * 备注  : /
 */
void init_485(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size, GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
    HAL_UART_Receive_IT(huart, pData, Size);
    HAL_GPIO_WritePin(GPIOx, GPIO_Pin, GPIO_PIN_RESET);
}
