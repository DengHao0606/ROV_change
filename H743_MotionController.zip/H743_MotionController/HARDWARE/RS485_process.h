#ifndef __RS485_PROCESS_H
#define __RS485_PROCESS_H

#include "main.h"

void Transmit_485_IT(UART_HandleTypeDef *huart, uint8_t *buf, uint16_t len, GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void init_485(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size, GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);

#endif
